//Ex10-클릭한 컬럼을 기준으로 레코드 정렬하기 #1
window.addEventListener("load", function(){

    var notices = [
        {"id":1, "title":"유투브에 끌려다니지 않으려고 했는데....ㅜㅜ..", "regDate":"2019-02-05", "writerId":"newlec", "hit":2},
        {"id":2, "title":"자바스크립트란..", "regDate":"2019-02-02", "writerId":"newlec", "hit":0},
        {"id":3, "title":"기본기가 튼튼해야....", "regDate":"2019-02-01", "writerId":"newlec", "hit":1},
        {"id":4, "title":"근데 조회수가 ㅜㅜ..", "regDate":"2019-01-25", "writerId":"newlec", "hit":0}
    ];

    var section = document.querySelector("#section10");
    
    var noticeList =section.querySelector(".notice-list");
    var titldTd = section.querySelector(".title");
    var tbodyNode = noticeList.querySelector("tbody");

    var bindData = function(){
        var template = section.querySelector("template");

        for(var i=0; i<notices.length; i++){
            var cloneNode = document.importNode(template.content, true);
            var tds = cloneNode.querySelectorAll("td");
            tds[0].textContent = notices[i].id;            

            var aNode = tds[1].children[0];
            aNode.href=notices[i].id;
            aNode.textContent = notices[i].title;

            tds[2].textContent = notices[i].regDate;
            tds[3].textContent = notices[i].writerId;
            tds[4].textContent = notices[i].hit;

            tbodyNode.appendChild(cloneNode);
        }
    };

    bindData();

    var titleSorted = false;

    titldTd.onclick = function(){
        tbodyNode.innerHTML = "";

        if(!titleSorted) {
            notices.sort(function(a,b){
                titleSorted = true;
                
                if(a.title < b.title) {
                    return -1;
                } else if(a.title > b.title) {
                    return 1;
                } else {
                    return 0;
                }
            });
        } else {
            notices.reverse();
        }
        
        bindData();
    };
});

//Ex9-다중 노드선택 방법과 일괄삭제, 노드의 자리바꾸기
window.addEventListener("load", function(){

    var section = document.querySelector("#section9");
    
    var noticeList =section.querySelector(".notice-list"); 
    var tbody = noticeList.querySelector("tbody");
    var allCheckbox = section.querySelector(".overall-checkbox");
    var delButton = section.querySelector(".del-button");
    var swapButton = section.querySelector(".swap-button");

    allCheckbox.onchange = function(){
        var checkboxes = tbody.querySelectorAll("input[type='checkbox']");

        for(var i=0; i<checkboxes.length; i++) {
            checkboxes[i].checked = allCheckbox.checked;
        }

    };

    delButton.onclick = function(){
        var checkedboxes = tbody.querySelectorAll("input[type='checkbox']:checked");
        
        for(var i=0; i<checkedboxes.length; i++) {
            checkedboxes[i].parentElement.parentElement.remove();
        }

    };

    swapButton.onclick = function(){
        var checkedboxes = tbody.querySelectorAll("input[type='checkbox']:checked");                

        if(checkedboxes.length != 2) {
            alert("2개만 선택해주세요!");
            return;
        }
        
        var trs = [];
        for(var i=0; i<checkedboxes.length; i++) {
            trs.push(checkedboxes[i].parentElement.parentElement);
        }

        var cloneNode = trs[0].cloneNode(true);
        trs[1].replaceWith(cloneNode);
        trs[0].replaceWith(trs[1]);
    };

});

//Ex8-노드 삽입과 바꾸기
window.addEventListener("load", function(){

    var section = document.querySelector("#section8");
    
    var noticeList =section.querySelector(".notice-list"); 
    var tbodyNode = noticeList.querySelector("tbody");
    var upButton = section.querySelector(".up-button");
    var downButton = section.querySelector(".down-button");

    var currentNode = tbodyNode.firstElementChild;//.children[0];

    downButton.onclick = function(){
        var nextNode = currentNode.nextElementSibling;

        if(nextNode == null) {
            alert("더 이상 이동할 수 없습니다.");
            return;
        }

        currentNode.insertAdjacentElement("beforebegin", nextNode);
        //tbodyNode.removeChild(nextNode);
        //tbodyNode.insertBefore(nextNode, currentNode);
    };

    upButton.onclick = function(){
       var prevNode = currentNode.previousElementSibling;

       if(prevNode == null) {
        alert("더 이상 이동할 수 없습니다.");
        return;
       }

       currentNode.insertAdjacentElement("afterend", prevNode);
       //tbodyNode.removeChild(currentNode);
       //tbodyNode.insertBefore(currentNode, prevNode);
    };

});

// Ex7 : 엘리먼트 노드의 속성 & CSS 속성 변경
window.addEventListener("load", function(){
    const notices = [
        {id:5, title:"what?", regDate:"2020-03-01", writerId:"you", hit:0},
        {id:6, title:"what!", regDate:"2020-03-01", writerId:"you", hit:0}
    ];

    const sec = document.querySelector("#sec7");
    const noticeList = sec.querySelector(".notice-list");
    const tbodyNode = noticeList.querySelector("tbody");
    const cloneButton = sec.querySelector(".clone-button");
    const templateButton = sec.querySelector(".template-button");

    cloneButton.onclick = function() {
        const trNode = noticeList.querySelector("tbody tr");
        const cloneNode = trNode.cloneNode(true);
        const tds = cloneNode.querySelectorAll("td");

        tds[0].textContent = notices[0].id;
        tds[1].innerHTML = '<a href="">'+notices[0].title+'</a>';
        tds[2].textContent = notices[0].regDate;
        tds[3].textContent = notices[0].writerId;
        tds[4].textContent = notices[0].hit;

        tbodyNode.append(cloneNode);
    };

    templateButton.onclick = function() {
        const template = sec.querySelector("template");
        const cloneNode = document.importNode(template.content, true);
        const tds = cloneNode.querySelectorAll("td");

        tds[0].textContent = notices[0].id;
        tds[1].innerHTML = '<a href="">'+notices[0].title+'</a>';
        tds[2].textContent = notices[0].regDate;
        tds[3].textContent = notices[0].writerId;
        tds[4].textContent = notices[0].hit;

        tbodyNode.append(cloneNode);
    };
});

// Ex6 : 노드조작 - 메뉴추가
window.addEventListener("load", function(){
    const sec = document.querySelector("#sec6");
    const titleInput = sec.querySelector(".title-input");
    const menuListUl = sec.querySelector(".menu-list");
    const addButton = sec.querySelector(".add-button");
    const delButton = sec.querySelector(".del-button");

    addButton.onclick = function() {
        const title = titleInput.value;
        const html = '<a href="">'+title+'</a>';
        const li = document.createElement("li");
        li.innerHTML = html;

        menuListUl.append(li);
    };

    delButton.onclick = function() {
        const liNode = menuListUl.children[0];
        liNode.remove();
    };
});

// Ex6 : 노드조작 - 메뉴추가
// window.addEventListener("load", function(){
//     const sec = document.querySelector("#sec6");
//     const titleInput = sec.querySelector(".title-input");
//     const menuListDiv = sec.querySelector(".menu-list");
//     const addButton = sec.querySelector(".add-button");
//     const delButton = sec.querySelector(".del-button");

//     addButton.onclick = function() {
//         const title = titleInput.value;
//         const txtNode = document.createTextNode(title);
//         menuListDiv.appendChild(txtNode);
//     };

//     delButton.onclick = function() {
//         const txtNode= menuListDiv.childNodes[0];
//         menuListDiv.removeChild(txtNode);
//     };
// });

// Ex5 : 엘리먼트 노드의 속성 & CSS 속성 변경
window.addEventListener("load", function(){
    const sec = document.querySelector("#sec5");
    const srcInput = sec.querySelector(".src-input");
    const imgSelect = sec.querySelector(".img-select");
    const changeButton = sec.querySelector(".change-button");
    const img = sec.querySelector(".img");
    const colorInput = sec.querySelector(".color-input");

    changeButton.onclick = function() {
        //img.src="images/" + imgSelect.value;
        img.src="images/" + srcInput.value;
    
        img.style.borderColor = colorInput.value;
    }
});

// Ex4 : childNodes를 이용한 노드 선택
window.addEventListener("load", function(){
    const sec4 = document.querySelector("#sec4");
    const box = sec4.querySelector(".box");

    const input1 = box.children[0]
    const input2 = box.children[1];

    input1.value="hi";
    input2.value="yep";
});

// Ex3 : Selectors API Level 1
window.addEventListener("load", function(){
    const sec3 = document.getElementById("sec3"); 

    const txtX = sec3.querySelector(".txt-x");
    const txtY = sec3.querySelector(".txt-y");
    const btnAdd = sec3.querySelector(".btn-add");
    const txtSum = sec3.querySelector(".txt-sum");

    btnAdd.onclick = function() {
        const x =  parseInt(txtX.value);
        const y =  parseInt(txtY.value);

        txtSum.value = x+y;
    };
});

// Ex2 : 엘리먼트 선택 개선
window.addEventListener("load", function(){
    const sec2 = document.getElementById("sec2"); 

    const txtX = sec2.getElementsByClassName("txt-x")[0];
    const txtY = sec2.getElementsByClassName("txt-y")[0];
    const btnAdd = sec2.getElementsByClassName("btn-add")[0];
    const txtSum = sec2.getElementsByClassName("txt-sum")[0];

    btnAdd.onclick = function() {
        const x =  parseInt(txtX.value);
        const y =  parseInt(txtY.value);

        txtSum.value = x+y;
    };
});

// Ex1 : 계산기 프로그램
window.addEventListener("load", function(){
    const txtX = document.getElementById("txt-x"); 
    const txtY = document.getElementById("txt-y"); 
    const btnAdd = document.getElementById("btn-add"); 
    const txtSum = document.getElementById("txt-sum"); 

    btnAdd.onclick = function() {
        const x =  parseInt(txtX.value);
        const y =  parseInt(txtY.value);

        txtSum.value = x+y;
    };
});

