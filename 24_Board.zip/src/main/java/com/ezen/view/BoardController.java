package com.ezen.view;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.board.BoardService;
import com.ezen.dto.BoardDto;
import com.ezen.util.Criteria;
import com.ezen.util.PageMaker;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;

	/*
	 * 게시판 조회
	 */
	@RequestMapping("/board_list")
	public String getBoardList(Model model) {
		List<BoardDto> boardList = boardService.getBoardList();
		model.addAttribute("boardList", boardList);
		
		return "board/list";
	}
	
	/*
	 * 게시판 조회_페이징
	 */
	@RequestMapping("/board_list_paging")
	public String getBoardListPaging(Criteria criteria, Model model) {
		System.out.println("criteria = " + criteria);
		List<BoardDto> boardList = boardService.getBoardListPaging(criteria);
		System.out.println("criteria = " + criteria);
		System.out.println("boardList = " + boardList);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(criteria);
		pageMaker.setTotalCount(boardService.getBoardCount());
		System.out.println("pageMaker = " + pageMaker);
		
		model.addAttribute("pageMaker", pageMaker);
		model.addAttribute("boardList", boardList);
				
		return "board/list";
	}
	
	/*
	 * 게시글 조회
	 */
	@GetMapping("/board")
	public String getBoard(BoardDto board, Model model) {
		BoardDto boardDto = boardService.getBoard(board);
		model.addAttribute("board", boardDto);
		boardService.updateHit(board);
		
		return "board/board";
	}
	
	// 글 등록 뷰
	@GetMapping("/board_write_view")
	public String getBoardWriteView() {
		
		return "board/write";
	}
	
	/*
	 * 글 등록
	 */
	@PostMapping("/board_write")
	public String insertBoard(BoardDto board) {
		boardService.insertBoard(board);
		
		return "redirect:board_list_paging";
	}
	
	/*
	 * 글 수정
	 */
	@PostMapping("/board_update")
	public String updateBoard(BoardDto board) {
		boardService.updateBoard(board);
		
		return "redirect:board_list";
	}
	
	/*
	 * 글 삭제
	 */
	@PostMapping("/board_delete")
	public String deleteBoard(BoardDto board) {
		boardService.deleteBoard(board);
		
		return "redirect:board_list";
	}
}
