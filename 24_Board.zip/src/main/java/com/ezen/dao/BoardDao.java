package com.ezen.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.dto.BoardDto;
import com.ezen.util.Criteria;

@Repository
public class BoardDao {
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 게시판 조회
	public List<BoardDto> getBoardList() {
		
		return myBatis.selectList("boardMapper.getBoardList");
	}
	
	// 게시판 조회_페이징
	public List<BoardDto> getBoardListPaging(Criteria criteria) {
		
		return myBatis.selectList("boardMapper.getBoardListPaging", criteria);
	}
	
	// 총 게시글 수 계산
	public int getBoardCount() {
		
		return myBatis.selectOne("boardMapper.getBoardCount");
	}
		
	// 글 조회
	public BoardDto getBoard(BoardDto board) {
		
		return myBatis.selectOne("boardMapper.getBoard", board);
	}
	
	// 좋아요
	public void updateHit(BoardDto board) {
		
		myBatis.update("boardMapper.updateHit", board);
	}	
	
	// 글 등록
	public void insertBoard(BoardDto board) {
		
		myBatis.insert("boardMapper.insertBoard", board);
	}
	
	// 글 수정
	public void updateBoard(BoardDto board) {
		
		myBatis.insert("boardMapper.updateBoard", board);
	}
	
	// 글 삭제
	public void deleteBoard(BoardDto board) {
		myBatis.delete("boardMapper.deleteBoard", board);
	}

}
