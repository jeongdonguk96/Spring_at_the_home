package com.ezen.board;

import java.util.List;

import com.ezen.dto.BoardDto;
import com.ezen.util.Criteria;

public interface BoardService {
	// 게시판 조회
	List<BoardDto> getBoardList();
	
	// 게시판 조회_페이징
	List<BoardDto> getBoardListPaging(Criteria criteria);
	
	// 총 게시글 수 계산
	int getBoardCount();	
	
	// 글 조회
	BoardDto getBoard(BoardDto board);

	// 좋아요
	void updateHit(BoardDto board);
	
	// 글 등록
	void insertBoard(BoardDto board);
	
	// 글 수정
	void updateBoard(BoardDto board);

	// 글 삭제
	void deleteBoard(BoardDto board);
}
