package com.ezen.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.dao.BoardDao;
import com.ezen.dto.BoardDto;
import com.ezen.util.Criteria;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardDao boardDao;

	// 게시판 조회
	@Override
	public List<BoardDto> getBoardList() {
		return boardDao.getBoardList();
	}
	
	// 게시판 조회_페이징
	@Override
	public List<BoardDto> getBoardListPaging(Criteria criteria) {
		return boardDao.getBoardListPaging(criteria);
	}

	// 총 게시글 수 계산
	@Override
	public int getBoardCount() {
		return boardDao.getBoardCount();
	}
	
	// 글 조회
	@Override
	public BoardDto getBoard(BoardDto board) {
		return boardDao.getBoard(board);
	}
	
	// 좋아요
	@Override
	public void updateHit(BoardDto board) {
		boardDao.updateHit(board);
	}
	
	// 글 등록
	@Override
	public void insertBoard(BoardDto board) {
		boardDao.insertBoard(board);
	}

	// 글 조회
	@Override
	public void updateBoard(BoardDto board) {
		boardDao.updateBoard(board);
	}

	// 글 삭제
	@Override
	public void deleteBoard(BoardDto board) {
		boardDao.deleteBoard(board);
	}

}
