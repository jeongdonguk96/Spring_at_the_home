package com.ezen.util;

public class Criteria {
	private int page;
	private int pageSize;
	
	public Criteria() {
		this(1, 10);
	}

	public Criteria(int page, int pageSize) {
		this.page = page;
		this.pageSize = pageSize;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		if(page<=0) {
			this.page = 1;
		} else {			
			this.page = page;
		}
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		if(pageSize<=0 || pageSize>10) {
			this.pageSize = 10;
		} else {
			this.pageSize = pageSize;			
		}
	}
	
	/*
	 * 네비게이션의 첫 페이지
	 */
	public int getBeginPage() {
		
		return (page-1) * pageSize + 1;
	}

	@Override
	public String toString() {
		return "Criteria [page=" + page + ", pageSize=" + pageSize + "]";
	}
}
