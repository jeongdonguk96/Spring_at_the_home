package com.ezen.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

/*
 * 화면에 표시할 페이지 버튼 정보 저장
 */

public class PageMaker {
	private Criteria criteria; // 현재 페이지 정보
	private int totalCount; // 총 게시글 수
	private int beginPage; // 네비게이션의 첫 페이지 번호
	private int endPage; // 네비게이션의 마지막 페이지 번호
	private boolean prev; // 이전 페이지로 이동하는 링크를 보여줄 것인지 여부
	private boolean next; // 다음 페이지로 이동하는 링크를 보여줄 것인지 여부
	private int naviSize = 10;
	private int totalPage; // 전체 페이지 수
	
	public Criteria getCriteria() {
		return criteria;
	}
	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}
	public int getTotalCount() {
		return totalCount;
	}
	// 전체 게시글의 수 저장 및 멤버변수 초기화
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		
		fieldInit();
	}
	public void fieldInit() {
		endPage = (int) (Math.ceil(criteria.getPage() / (double) naviSize) * naviSize);
			// ex)네비게이션의 마지막 페이지 : 올림(23/10) * 10 => 30
		
		beginPage = endPage - naviSize + 1;
			// ex)네비게이션의 첫 페이지 : 30 - 10 + 1 => 21
		
		totalPage = (int) Math.ceil(totalCount / (double) criteria.getPageSize());
			// ex)전체 페이지의 수 : 올림(253 / 10) => 26
		
		if(endPage > totalPage) endPage = totalPage;
			// 계산한 endPage가 totalPage보다 클 경우 totalPage의 값을 endPage의 값으로 수정
		
		prev = beginPage==1 ? false : true;
			// 네비게이션의 첫 페이지가 1이면 false 그 외엔 true로 표시
		
		next = endPage * criteria.getPageSize() < totalCount ? true : false;
			// 26 * 10 < 253 ? true : false
	}
	// 화면에서 페이지를 누르면 URL의 쿼리스트링에 페이지 번호와 페이지당 게시글 수를 조립해주는 매서드
	public String makeQuery(int page) {
		UriComponents uriCompo = UriComponentsBuilder.newInstance()
								.queryParam("page", page)
								.queryParam("pageSize", criteria.getPageSize())
//								.queryParam("searchCondition", ((SearchCriteria) criteria).getSearchCondition())
//								.queryParam("keyword", encoding(((SearchCriteria) criteria).getSearchKeyword()))
								.build();
		// ex) ?page=3&pageSize=10
		
		return uriCompo.toString();
	}
	
	private String encoding(String keyword) {
		if(keyword == null || keyword.trim().length() == 0) {
			return "";
		}
		try {
			return URLEncoder.encode(keyword, "UTF-8");
		} catch(UnsupportedEncodingException e) {
			return "";
		}
	}
	
	public int getBeginPage() {
		return beginPage;
	}
	public void setBeginPage(int beginPage) {
		this.beginPage = beginPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public boolean isPrev() {
		return prev;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	public boolean isNext() {
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	public int getNaviSize() {
		return naviSize;
	}
	public void setNaviSize(int naviSize) {
		this.naviSize = naviSize;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
	@Override
	public String toString() {
		return "PageMaker [criteria=" + criteria + ", totalCount=" + totalCount + ", beginPage=" + beginPage
				+ ", endPage=" + endPage + ", prev=" + prev + ", next=" + next + ", naviSize=" + naviSize
				+ ", totalPage=" + totalPage + "]";
	}
}
