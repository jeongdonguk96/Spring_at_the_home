package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BoardDto {
	private int bno;
	private String title;
	private String content;
	private String writer;
	private int hit;
	private Date regDate;
}
