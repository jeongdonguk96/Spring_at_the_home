package com.cos.blog;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cos.blog.domain.Member;
import com.cos.blog.domain.Role;
import com.cos.blog.persistence.MemberRepository;

import jakarta.transaction.Transactional;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class DummyControllerTest2 {
	@Autowired
	private MemberRepository memberRepo;
	
	@Test
	@Disabled
	public void join() {
		Member mem1 = new Member();
		mem1.setName("1111");
		mem1.setPassword("1111");
		mem1.setEmail("email.google.com");
		mem1.setRole(Role.USER);
		memberRepo.save(mem1);
		
		Member mem2 = new Member();
		mem2.setName("2222");
		mem2.setPassword("2222");
		mem2.setEmail("email.google.com");
		mem2.setRole(Role.USER);
		memberRepo.save(mem2);
		
		Member mem3 = new Member();
		mem3.setName("3333");
		mem3.setPassword("3333");
		mem3.setEmail("email.google.com");
		mem3.setRole(Role.USER);
		memberRepo.save(mem3);
	}
	
	@Test
	@Disabled
	public void select() {
		Member member = memberRepo.findById(1L).get();
		System.out.println("member: " + member);
	}
	
	// 업데이트의 경우 해당 데이터를 조회 후 save하는 방식으로 했지만
	// 조회한 순간에 영속성 컨텍스트에 해당 데이터가 객체화돼 올라가기 때문에
	// 또 다시 save로 동일한 데이터를 다시 영속성 컨텍스트에 올릴 필요가 없다.
	// 그래서 @Transactional을 붙여서 조회 시 올라와 있는 데이터를 이용해 save없이 수정할 수가 있다.
	// 즉 조회할 때 영속성 컨텍스트에 올라온 데이터가 매서드(트랜잭션) 끝날 시에 변경을 감지하고 컨텍스트에서 이탈돼
	// 수정된 정보로 DB에 들어가게 된다(= flush).
	@Transactional
	@Test
	@Disabled
	public void update() {
		Member member = memberRepo.findById(3L).get();
		
		member.setName("33333");
		member.setPassword("33333");
	}
	
	@Test
	@Disabled
	public void delete() {
		memberRepo.deleteById(3L);
	}
}
