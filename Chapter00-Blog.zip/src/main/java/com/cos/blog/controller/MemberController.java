package com.cos.blog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/member/")
public class MemberController {
	
	// 회원가입 화면 이동
	@GetMapping("/join")
	public String joinForm() {
		
		return "member/join";
	}

	// 로그인 화면 이동
	@GetMapping("/login")
	public String loginForm() {
		
		return "member/login";
	}

}





















