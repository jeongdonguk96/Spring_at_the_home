package com.cos.blog.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cos.blog.config.auth.PrincipalDetail;
import com.cos.blog.domain.Board;
import com.cos.blog.service.BoardService;

import dto.ResponseDto;

@RestController
@RequestMapping("/api/board/")
public class BoardApiController {
	@Autowired
	private BoardService boardService;
	
	/*
	 * 글 작성
	 */
	@PostMapping("/save")
	public ResponseDto<Integer> save(@RequestBody Board board, // @RequestBody: json 사용을 위해
									@AuthenticationPrincipal PrincipalDetail principal) {
								 // @AuthenticationPrincipal: 시큐리티를 통해 로그인한 유저의 정보를 가져옴
		boardService.save(board, principal.getMember());
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}
	
	/*
	 * 글 삭제
	 */
	@DeleteMapping("/delete/{bno}")
	public ResponseDto<Integer> delete(@PathVariable Long bno) { // @pathvariable: URL 경로에 변수명을 넣을 수 있게 해줌
		boardService.delete(bno);
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1); 
	}
	
	/*
	 * 글 수정
	 */
	@PutMapping("/update/{bno}")
	public ResponseDto<Integer> update(@PathVariable Long bno, // @pathvariable: URL 경로에 변수명을 넣을 수 있게 해줌
									  @RequestBody Board board) { 
		System.out.println("컨트롤러 bno = " + bno);
		System.out.println("컨트롤러 board = " + board);
		boardService.update(bno, board);
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1); 
	}
}

