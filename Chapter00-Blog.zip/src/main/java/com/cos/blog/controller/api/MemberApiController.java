package com.cos.blog.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cos.blog.config.auth.PrincipalDetail;
import com.cos.blog.domain.Member;
import com.cos.blog.domain.Role;
import com.cos.blog.service.MemberService;

import dto.ResponseDto;
import jakarta.servlet.http.HttpSession;

@RestController
public class MemberApiController {
	@Autowired
	private MemberService memberService;
	/*
	 * 회원가입
	 */
	@PostMapping("/auth/join")
	public ResponseDto<Integer> save(@RequestBody Member member) {
		member.setRole(Role.USER);
		memberService.join(member);
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}
	
	/*
	 * 회원정보 수정
	 */
	@PutMapping("/api/member/update")
	public ResponseDto<Integer> update(@RequestBody Member member,
										@AuthenticationPrincipal PrincipalDetail principal,
										HttpSession session) {
		memberService.update(member);
		
		// 회원정보 수정 시 DB에는 값이 바뀌지만 수정 후에도 로그인이 유지되면 
		// 바뀌기 전 정보가 남아있는 문제를 해소하기 위해 사용하는 방식
		// 변경된 정보를 토대로 새로 세션 등록 - 포기..

		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}
	
}
