package com.cos.blog.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cos.blog.domain.Member;
import com.cos.blog.domain.Role;
import com.cos.blog.service.MemberService;

import dto.ResponseDto;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/")
public class MemberApiController {
	@Autowired
	private MemberService memberService;
	
	/*
	 * 세션을 얻을 때 여기서 DI해서 사용 가능
	@Autowired
	private HttpSession session;
	*/
	
	/*
	 * 회원가입
	 */
	@PostMapping("/member")
	public ResponseDto<Integer> save(@RequestBody Member member) {
		member.setRole(Role.USER);
		memberService.join(member);
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}
	
	/*
	 * 로그인 - 전통적인 스프링 방식(sql을 통해 로그인, 세션에 정보를 저장)
	@PostMapping("/member/login")
	public ResponseDto<Integer> login(@RequestBody Member member) {
		Member principal =  memberService.login(member);		
		if(principal != null) {
			session.setAttribute("principal", principal);
		}
		
		return new ResponseDto<Integer>(HttpStatus.OK.value(), 1);
	}
	*/
}
