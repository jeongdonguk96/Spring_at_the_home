package com.cos.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.blog.domain.Board;
import com.cos.blog.domain.Member;
import com.cos.blog.persistence.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardRepository boardRepo;
	
	// 글 등록
	@Transactional
	public void save(Board board, Member member) {
		board.setCount(0L);
		board.setMember(member);
		boardRepo.save(board);
	}

}

