package com.cos.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.blog.domain.Board;
import com.cos.blog.domain.Member;
import com.cos.blog.persistence.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardRepository boardRepo;
	
	// 글 목록 조회
	@Transactional(readOnly = true)
	public Page<Board> getBoardList(Pageable pageable) {
		
		return boardRepo.findAll(pageable);
	}
	
	
	// 글 보기
	@Transactional(readOnly = true)
	public Board getBoard(Long bno) {
		
		return boardRepo.findById(bno).get();
	}
	
	// 글 등록
	@Transactional
	public void save(Board board, Member member) {
		board.setCount(0L);
		board.setMember(member);
		boardRepo.save(board);
	}
	
	// 글 삭제
	@Transactional
	public void delete(Long bno) {
		System.out.println("impl컨트롤러 bno : " + bno);
		boardRepo.deleteById(bno);
	}
	
	// 글 수정 - 더티체킹으로 자동 업데이트(DB단으로 플러쉬)
	@Transactional
	public void update(Long bno, Board board) {
		Board theBoard = boardRepo.findById(bno).get();
		theBoard.setTitle(board.getTitle());
		theBoard.setContent(board.getContent());		
		System.out.println("서비스단 bno = " + bno);
		System.out.println("서비스단 board = " + board);
		System.out.println("서비스단 theBoard = " + theBoard);
	}
	
}

