package com.cos.blog.service;

import com.cos.blog.domain.Board;
import com.cos.blog.domain.Member;

public interface BoardService {
	void save(Board board, Member member);	
}

