package com.cos.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.blog.domain.Member;
import com.cos.blog.persistence.MemberRepository;

@Service
public class MemberServiceImpl implements MemberService {
	@Autowired
	private MemberRepository memberRepo;
	
	// 회원가입
	@Transactional
	@Override
	public void join(Member member) {
		
		memberRepo.save(member);
	}
	
	// 로그인
	@Transactional(readOnly = true) // 매서드 시작 시 트랜잭션 시작, 매서드 종료 시 트랜잭션 종료(=> 정합성 유지) 
	@Override
	public Member login(Member member) {
		
		return memberRepo.findByNameAndPassword(member.getName(), member.getPassword());
	}

}
