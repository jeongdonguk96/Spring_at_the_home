package com.cos.blog.service;

import com.cos.blog.domain.Member;

public interface MemberService {
	void join(Member member);
	
}

//Member login(Member member);