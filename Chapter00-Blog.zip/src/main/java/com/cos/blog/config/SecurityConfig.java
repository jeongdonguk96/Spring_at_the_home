package com.cos.blog.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.cos.blog.config.auth.PrincipalDetailService;

@Configuration // 빈 등록
@EnableWebSecurity // 해당 클래스를 시큐리티 필터로 등록
@EnableGlobalMethodSecurity(prePostEnabled = true) // 특정 주소로 접근할 때 권한/인증을 미리 체크
public class SecurityConfig extends WebSecurityConfiguration{
	@Autowired
	private PrincipalDetailService principalDetailService;
	
	/*
	 * 로그인 시큐리티 필터 클래스 
	 * HttpSecurity: 어플리케이션 자원에 대한 인증과 인가를 제어하는 클래스
	 * csrf(Cross Site Request Forgery): 자신의 의도와 상관없이 웹 사이트를 공격하는 행위
	 * (1) csrf는 스프링 시큐리티 사용 시 자동 발동 => uuid로 csrfToken을 생성해 세션에 유저정보와 함께 넘겨줌
	 * (2) 서버단에서 유저 로그인 시 csrfToken이 있는지 없는지 여부로 정상 로그인인지 아닌지를 확인!!
	 * 
	 */
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
			.csrf().disable() // csrf 토큰 비활성화
			.authorizeHttpRequests()
				.requestMatchers("/auth/**", "/css/**", "/js/**", "/") // ("URL")의 요청은
				.permitAll() 										   // 인증 없이 모두 허락
				.anyRequest()  										   // 이외의 모든 요청은
				.authenticated() 									   // 인증이 필요
			.and()
				.formLogin()
				.loginPage("/auth/loginForm") 	   // 로그인 페이지를 ("URL")로 설정
				.loginProcessingUrl("/auth/login") // 시큐리티가 ("URL")로 오는 요청을 가로채 로그인 처리하도록 설정
				.defaultSuccessUrl("/"); 		   // 로그인 성공 시 ("URL")로 이동
		
		return http.build();
	}
	
	/*
	 * 비밀번호 해쉬화
	 */
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	/*
	 * (1) 로그인은 시큐리티가 가로채 처리
	 * (2) 이때 DB에 등록된 password가 어떻게 해쉬화돼있는지 알아야함
	 * (3) 그래야 입력된 password도 해쉬화해 DB상 password와 비교할 수 있음.
	 * 시큐리티의 password 인증 처리(name은 PrincipalDetailService에)
	 */
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(principalDetailService).passwordEncoder(passwordEncoder());
	}

}










