package com.cos.blog.config.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cos.blog.domain.Member;
import com.cos.blog.persistence.MemberRepository;

@Service
public class PrincipalDetailService implements UserDetailsService{
	@Autowired
	private MemberRepository memberRepo;
	
	/*
	 * (1) 시큐리시가 로그인 처리를 가로챌 때 입력받은 name과 password 2가지를 가로챔
	 * (2) 아래 매서드는 name만 DB에 있는지 확인하는 매서드
	 * 시큐리티의 name 인증 처리(password는 SecurityConfig에)
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Member principal = memberRepo.findByUsername(username).get();
		
		return new PrincipalDetail(principal); // UserDetails를 구현한 PrincipalDetail 타입으로
											   // 시큐리티 세션 저장소에 유저정보가 들어감
	}
}
