package com.cos.blog.domain;

import lombok.Data;

// 카카오 로그인 api를 받기 위한 도메인
@Data
public class OAuthToken {
	private String access_token;
	private String token_type;
	private String refresh_token;
	private int expires_in;
	private String scope;
	private int refresh_token_expires_in;
}
