package com.cos.blog.domain;

public enum Role {
	USER, ADMIN
}
