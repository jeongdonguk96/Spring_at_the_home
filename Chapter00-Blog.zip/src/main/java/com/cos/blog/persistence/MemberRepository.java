package com.cos.blog.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cos.blog.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {	
	/*
	 * 네이티브 쿼리를 생성해 사용하는 방식(어려운 쿼리문에 사용)
	 * @Query(value="SELECT m FROM Member m WHERE name=? AND password=?", nativeQuery = true)
	 * Member login(String name, String password); 
	 */
	
	// JPA Naming 전략 (매서드명을 변수명과 맞추면 알아서 인식)
	Member findByNameAndPassword(String name, String password);
	
}
