package com.cos.blog.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cos.blog.domain.Board;
import com.cos.blog.domain.Member;
import com.cos.blog.domain.Reply;

import dto.ReplySaveRequestDto;

public interface BoardService {
	Page<Board> getBoardList(Pageable pageable);
	
	Board getBoard(Long bno);
	
	void save(Board board, Member member);
	
	void delete(Long bno);
	
	void update(Long bno, Board board);
	
	void saveReply(Member member, Long bno, Reply requestReply);
	
	void saveReply(ReplySaveRequestDto replySaveRequestDto);
	
	void saveReplyNativeQuery(ReplySaveRequestDto replySaveRequestDto);
}

