package com.cos.blog.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import com.cos.blog.domain.Reply;

public interface ReplyRepository extends JpaRepository<Reply, Long> {
	@Modifying
	@Query(value = "INSERT INTO reply(content, board_id, member_id) VALUES(?1, ?2, ?3)", nativeQuery = true) 
	int replySave(String content, Long Board_id, Long member_id); // 수정된 행의 갯수를 리턴하기 때문에 int로
}
