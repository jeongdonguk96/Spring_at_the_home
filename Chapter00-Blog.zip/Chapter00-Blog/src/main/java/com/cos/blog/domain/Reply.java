package com.cos.blog.domain;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
public class Reply {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long rno;
	@Column(nullable = false, length = 200)
	private String content;
	@ManyToOne
	@JoinColumn(name = "board_id")
	private Board board;
	@ManyToOne
	@JoinColumn(name = "member_id")
	private Member member;
	@CreationTimestamp
	private Timestamp regDate;
}
