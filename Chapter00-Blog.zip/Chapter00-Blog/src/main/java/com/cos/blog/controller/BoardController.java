package com.cos.blog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cos.blog.domain.Board;
import com.cos.blog.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;	
	
	// 인덱스 화면(글목록 조회)
	@GetMapping({"", "/"})
	public String index(Model model, @PageableDefault(size = 3, sort = "bno", direction = Sort.Direction.DESC) Pageable pageable) {
		Page<Board> boardList = boardService.getBoardList(pageable);
		model.addAttribute("boardList", boardList);
		
		return "index";
	}
	
	// 글 상세화면 이동
	@GetMapping("/board/getBoard")
	public String getBoard(Long bno, Model model) {
	 	Board board = boardService.getBoard(bno);
	 	model.addAttribute("board", board);
	 	
	 	return "board/detail";
	}
	
	// 글 작성 화면 이동
	@GetMapping("/board/saveForm")
	public String saveForm() {
		
		return "board/save";
	}
	
	// 글 수정 화면 이동
	@GetMapping("/board/updateForm")
	public String updateForm(Long bno, Model model) {
		Board board = boardService.getBoard(bno);
		
		model.addAttribute("board", board);
		return "board/update";
	}
	
}
