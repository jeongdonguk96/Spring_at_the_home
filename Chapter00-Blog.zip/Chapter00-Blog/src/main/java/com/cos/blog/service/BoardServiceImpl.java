package com.cos.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cos.blog.domain.Board;
import com.cos.blog.domain.Member;
import com.cos.blog.domain.Reply;
import com.cos.blog.persistence.BoardRepository;
import com.cos.blog.persistence.MemberRepository;
import com.cos.blog.persistence.ReplyRepository;

import dto.ReplySaveRequestDto;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardRepository boardRepo;
	@Autowired
	private ReplyRepository replyRepo;
	@Autowired
	private MemberRepository memberRepo;
	
	// 글 목록 조회
	@Transactional(readOnly = true)
	public Page<Board> getBoardList(Pageable pageable) {
		
		return boardRepo.findAll(pageable);
	}
	
	// 글 조회
	@Transactional(readOnly = true)
	public Board getBoard(Long bno) {
		
		return boardRepo.findById(bno).get();
	}
	
	// 글 등록
	@Transactional
	public void save(Board board, Member member) {
		board.setCount(0L);
		board.setMember(member);
		boardRepo.save(board);
	}
	
	// 글 삭제
	@Transactional
	public void delete(Long bno) {
		System.out.println("impl컨트롤러 bno : " + bno);
		boardRepo.deleteById(bno);
	}
	
	// 글 수정 - 더티체킹으로 자동 업데이트(DB단으로 플러쉬)
	@Transactional
	public void update(Long bno, Board board) {
		Board theBoard = boardRepo.findById(bno).get();
		theBoard.setTitle(board.getTitle());
		theBoard.setContent(board.getContent());		
	}
	
	// 댓글 작성 방법 1
	@Transactional
	public void saveReply(Member member, Long bno, Reply requestReply) {
		Board board = boardRepo.findById(bno).get();
		requestReply.setMember(member);
		requestReply.setBoard(board);
		replyRepo.save(requestReply);
	}
	
	// 댓글 작성 방법 2
	@Transactional
	public void saveReply(ReplySaveRequestDto replySaveRequestDto) {
		Member member = memberRepo.findById(replySaveRequestDto.getMid()).get();
		Board board = boardRepo.findById(replySaveRequestDto.getBno()).get();
		Reply reply = new Reply();
		reply.setMember(member);
		reply.setBoard(board);
		reply.setContent(replySaveRequestDto.getContent());
		replyRepo.save(reply);
	}

	// 댓글 작성 방법 3
	@Transactional
	public void saveReplyNativeQuery(ReplySaveRequestDto replySaveRequestDto) {

		replyRepo.replySave(replySaveRequestDto.getContent(), replySaveRequestDto.getBno(), replySaveRequestDto.getMid());
	}
	
}

