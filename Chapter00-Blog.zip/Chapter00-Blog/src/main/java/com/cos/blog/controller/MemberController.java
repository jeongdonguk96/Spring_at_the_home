package com.cos.blog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.cos.blog.domain.KakaoProfile;
import com.cos.blog.domain.Member;
import com.cos.blog.domain.OAuthToken;
import com.cos.blog.service.MemberService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class MemberController {
	@Value("${cos.key}")
	private String cosKey;
	@Autowired
	private MemberService memberService;
	
	// 회원가입 화면 이동
	@GetMapping("/auth/joinForm")
	public String joinForm() {
		
		return "member/join";
	}

	// 로그인 화면 이동
	@GetMapping("/auth/loginForm")
	public String loginForm() {
		
		return "member/login";
	}
	
	// 마이페이지 화면 이동
	@GetMapping("/member/mypage")
	public String mypage() {
		
		return "member/mypage";
	}
	
	// 카카오로그인 후 리다이렉트 화면
	@GetMapping("/auth/kakao/callback")
	public String kakaoCallback(String code) throws Exception {
		/*
		 * 1. 액세스 토큰 발급을 위해 카카오측에 json으로 정보를 보냄
		 */
		RestTemplate template = new RestTemplate();
		
		// HttpHeader 오브젝트 생성 (json의 헤더정보)
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
		
		// HttpBody 오브젝트 생성 (json의 바디정보)
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		String client_id = "161770d6be4249445e30ee0f4319b293";
		String redirect_uri = "http://localhost:8080/auth/kakao/callback";
		
		params.add("grant_type", "authorization_code");
		params.add("client_id", client_id);
		params.add("redirect_uri", redirect_uri);
		params.add("code", code);
		
		// HttpHeader와 HttpBody를 하나의 오브젝트에 담기 (json의 헤더와 바디를 담은 엔티티)
		HttpEntity<MultiValueMap<String, String>> kakaoTokenRequest = 
				new HttpEntity<>(params, headers);
		
		// 토큰을 얻기 위한 Http 요청
		ResponseEntity<String> response = template.exchange(
				"https://kauth.kakao.com/oauth/token", // 토큰을 요청할 url
				HttpMethod.POST, // 매서드 종류
				kakaoTokenRequest, // 헤더와 바디의 데이터
				String.class // 응답을 받을 타입
				);
		
		// 받은 정보 중 바디만 뽑아냄 그 후 선택적으로 액세스 토큰만 뽑아냄
		ObjectMapper objectMapper = new ObjectMapper();
		OAuthToken oAuthToken = null;
		try {
			oAuthToken = objectMapper.readValue(response.getBody(), OAuthToken.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		System.out.println("카카오 액세스 토큰 = " + oAuthToken.getAccess_token());
		
		
		/*
		 * 2. 받은 액세스 토큰으로 사용자 정보 조회 요청
		 */
		RestTemplate template2 = new RestTemplate();
		
		// HttpHeader 오브젝트 생성 (json의 헤더정보)
		HttpHeaders headers2 = new HttpHeaders();
		headers2.add("Authorization", "Bearer "+oAuthToken.getAccess_token());
		headers2.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
		
		// HttpHeader를 오브젝트에 담기 (json의 헤더를 담은 엔티티)
		HttpEntity<MultiValueMap<String, String>> kakaoProfileRequest = 
				new HttpEntity<>(headers2);
		
		// 토큰을 얻기 위한 Http 요청
		ResponseEntity<String> response2 = template2.exchange(
				"https://kapi.kakao.com/v2/user/me", // 토큰을 요청할 url
				HttpMethod.POST, // 매서드 종류
				kakaoProfileRequest, // 헤더와 바디의 데이터
				String.class // 응답을 받을 타입
				);
		
		System.out.println("토큰요청 결과 = " + response2.getBody());
		
		/*
		 *  3. 사용자 정보 받아오기 성공 후 로그인/회원가입 처리 
		 */
		ObjectMapper objectMapper2 = new ObjectMapper();
		KakaoProfile kakaoProfile = null;
		try {
			kakaoProfile = objectMapper2.readValue(response2.getBody(), KakaoProfile.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		System.out.println("kakaoProfile 아이디 = " + kakaoProfile.getId());
		System.out.println("kakaoProfile 어카운트  = " + kakaoProfile.getKakao_account());
		System.out.println("kakaoProfile 커넥트 = " + kakaoProfile.getConnected_at());
		System.out.println("kakaoProfile 프로퍼티 = " + kakaoProfile.getProperties());

		String blogUsername = kakaoProfile.getId() + "_" + kakaoProfile.getId();
		System.out.println("블로그서버 유저네임 = " + blogUsername);
		System.out.println("블로그서버 패스워드 = " + cosKey);
		
		// 카카오 사용자 정보를 토대로 회원가입
		Member kakaoMember = new Member();
		kakaoMember.setUsername(blogUsername);
		kakaoMember.setPassword(cosKey);
		kakaoMember.setEmail(blogUsername + "@.google.com");
		kakaoMember.setOauth("kakao");
		
		// 회원가입 시 이미 가입한 사용자면 바로 로그인, 아니면 회원가입 후 로그인 
		Member ogMember = memberService.getMember(kakaoMember.getUsername());
		System.out.println("ogMember = " + ogMember);
		if(ogMember.getUsername() == null) {
			System.out.println("신규 가입입니다");
			memberService.join(kakaoMember);		
		}
		
		// todo: 로그인 처리 로직 구현
		System.out.println("카카오api를 통해 로그인을 진행합니다");
		
	
		
		return "redirect:/"; // response.getBody(): 토큰의 바디만 받음
	}
	
}




















