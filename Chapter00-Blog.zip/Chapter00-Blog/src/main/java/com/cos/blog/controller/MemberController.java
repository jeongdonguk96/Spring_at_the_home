package com.cos.blog.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class MemberController {
	
	// 회원가입 화면 이동
	@GetMapping("/auth/joinForm")
	public String joinForm() {
		
		return "member/join";
	}

	// 로그인 화면 이동
	@GetMapping("/auth/loginForm")
	public String loginForm() {
		
		return "member/login";
	}
	
	// 마이페이지 화면 이동
	@GetMapping("/member/mypage")
	public String mypage() {
		
		return "member/mypage";
	}
	
	// 카카오로그인 후 리다이렉트 화면
	@GetMapping("/auth/kakao/callback")
	public @ResponseBody String kakaoCallback(String code) {
		/*
		 * 토큰발급을 위해 카카오측에 json으로 정보를 보냄
		 */
		RestTemplate template = new RestTemplate();
		
		// HttpHeader 오브젝트 생성 (json의 헤더정보)
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
		
		// HttpBody 오브젝트 생성 (json의 바디정보)
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		String client_id = "161770d6be4249445e30ee0f4319b293";
		String redirect_uri = "http://localhost:8080/auth/kakao/callback";
		
		params.add("grant_type", "authorization_code");
		params.add("client_id", client_id);
		params.add("redirect_uri", redirect_uri);
		params.add("code", code);
		
		// HttpHeader와 HttpBody를 하나의 오브젝트에 담기 (json의 헤더와 바디를 담은 엔티티)
		HttpEntity<MultiValueMap<String, String>> kakaoTokenRequest = 
				new HttpEntity<>(params, headers);
		
		// Http 요청
		ResponseEntity<String> response = template.exchange(
				"https://kauth.kakao.com/oauth/token", // 토큰을 요청할 url
				HttpMethod.POST, // 매서드 종류
				kakaoTokenRequest, // 헤더와 바디의 데이터
				String.class // 응답을 받을 타입
				);
		
		return "카카오 토큰요청 완료, 토큰요청에 대한 응답 = " + response;
	}
	
}





















