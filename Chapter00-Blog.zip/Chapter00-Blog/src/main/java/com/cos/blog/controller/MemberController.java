package com.cos.blog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MemberController {
	
	// 회원가입 화면 이동
	@GetMapping("/auth/joinForm")
	public String joinForm() {
		
		return "member/join";
	}

	// 로그인 화면 이동
	@GetMapping("/auth/loginForm")
	public String loginForm() {
		
		return "member/login";
	}
	
	// 마이페이지 화면 이동
	@GetMapping("/member/mypage")
	public String mypage() {
		
		return "member/mypage";
	}
	
}





















