package com.cos.blog.config.auth;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.cos.blog.domain.Member;

import lombok.Getter;

// (1) 스프링 시큐리티가 로그인 요청을 가로채 로그인을 진행
// (2) 완료 시 UserDetails 타입의 오브젝트를 시큐리티의 고유 세션 저장소에 저장

@Getter // @Getter: 글 등록 시 시큐리티를 통해 로그인한 유저의 정보를 가져오기 위해 사용
public class PrincipalDetail implements UserDetails{
	private Member member; // 포함관계
	
	public PrincipalDetail(Member member) {
		this.member = member;
	}

	@Override
	public String getPassword() {
		return member.getPassword();
	}

	@Override
	public String getUsername() {
		return member.getUsername();
	}

	// 계정 만료 여부 확인 (true: 만료x, false: 만료o => 사용 불가)
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	
	// 계정 잠금 여부 확인 (true: 잠금x, false: 잠금o => 사용 불가)
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	// 비밀번호 만료 여부 확인 (true: 만료x, false: 만료o => 사용 불가)
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	// 계정 활성화 여부 확인 (true: 활성화, false: 활성화x => 사용 불가)
	@Override
	public boolean isEnabled() {
		return true;
	}
	
	// 계정이 가진 권한 목록을 리턴(권한이 여러개일 시 for문으로 반복을 통해 해줘야 함)
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority> collectors = new ArrayList<>();
		collectors.add(()-> {return "ROLE_"+member.getRole();});
		
		/*
		collectors.add(new GrantedAuthority() {
			
			@Override
			public String getAuthority() {
				return "ROLE_"+member.getRole();
			}
		});
		*/
		
		return collectors;
	}
	
}
