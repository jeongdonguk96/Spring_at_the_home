package com.cos.blog.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cos.blog.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {

}
