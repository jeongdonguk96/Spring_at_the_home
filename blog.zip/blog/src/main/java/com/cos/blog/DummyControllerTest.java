package com.cos.blog;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cos.blog.domain.Member;
import com.cos.blog.persistence.MemberRepository;

@RestController
public class DummyControllerTest {
	@Autowired
	private MemberRepository memberRepo;
	
	@GetMapping("/dummy/user/{id}")
	public Member select(@PathVariable Long id) {
		Member member = memberRepo.findById(id).get();
		
		return member;
	}
	
	@GetMapping("/dummy/user")
	public List<Member> selectList() {
		
		return memberRepo.findAll();
	}
	
	@GetMapping("/dummy/page")
	public List<Member> pageList(@PageableDefault(size = 2, sort = "id", direction = Sort.Direction.DESC) Pageable pageable) {
		Page<Member> pagingUser = memberRepo.findAll(pageable);
		
		List<Member> users = pagingUser.getContent();
		return users;
	}
}
