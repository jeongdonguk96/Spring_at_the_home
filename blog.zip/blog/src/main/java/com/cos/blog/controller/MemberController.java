package com.cos.blog.controller;

public class MemberController {

}
