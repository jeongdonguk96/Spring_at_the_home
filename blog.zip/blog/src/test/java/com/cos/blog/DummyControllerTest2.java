package com.cos.blog;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cos.blog.domain.Member;
import com.cos.blog.domain.Role;
import com.cos.blog.persistence.MemberRepository;

import jakarta.transaction.Transactional;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class DummyControllerTest2 {
	@Autowired
	private MemberRepository memberRepo;
	
	@Test
	@Disabled
	public void join() {
		Member mem1 = new Member();
		mem1.setName("1111");
		mem1.setPassword("1111");
		mem1.setEmail("email.google.com");
		mem1.setRole(Role.USER);
		memberRepo.save(mem1);
		
		Member mem2 = new Member();
		mem2.setName("2222");
		mem2.setPassword("2222");
		mem2.setEmail("email.google.com");
		mem2.setRole(Role.USER);
		memberRepo.save(mem2);
		
		Member mem3 = new Member();
		mem3.setName("3333");
		mem3.setPassword("3333");
		mem3.setEmail("email.google.com");
		mem3.setRole(Role.USER);
		memberRepo.save(mem3);
	}
	
	@Test
	@Disabled
	public void select() {
		Member member = memberRepo.findById(1L).get();
		System.out.println("member: " + member);
	}
	
	@Transactional
	@Test
	@Disabled
	public void update() {
		Member member = memberRepo.findById(3L).get();
		
		member.setName("33333");
		member.setPassword("33333");
	}
	
	@Test
	@Disabled
	public void delete() {
		memberRepo.deleteById(3L);
	}
}
