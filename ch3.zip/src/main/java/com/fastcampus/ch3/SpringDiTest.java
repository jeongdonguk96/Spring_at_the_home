package com.fastcampus.ch3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component class Car{
    @Value("red") String color;
    @Value("100") int oil;
    @Autowired Engine engine; // @Autowired는 ByType으로 먼저 검색하고 타입이 여러 개면 ByName으로 검색
    @Autowired Door[] door; // @Autowired는 ByType으로 먼저 검색하고 타입이 여러 개면 ByName으로 검색

    public void setColor(String color) {
        this.color = color;
    }

    public void setOil(int oil) {
        this.oil = oil;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public void setDoor(Door[] door) {
        this.door = door;
    }

    @Override
    public String toString() {
        return "Car{" +
                "color='" + color + '\'' +
                ", oil=" + oil +
                ", engine=" + engine +
                ", door=" + Arrays.toString(door) +
                '}';
    }
}
@Component("engine") class Engine{} // @Component("engine")은 곧 <bean id="engine"(키) class="com.fastcampus.ch3.Engine"(밸류) />과 같은 의미
@Component class TurboEngine extends Engine{}
@Component class SuperEngine extends Engine{}
@Component class Door{}

public class SpringDiTest {
    public static void main(String[] args) {
        ApplicationContext ac = new GenericXmlApplicationContext("config.xml");

        // Car car = (Car) ac.getBean("car"); // ByName, 아래와 같은 문장
        Car car  = ac.getBean("car", Car.class);
        Car car2 = (Car) ac.getBean(Car.class); // ByType
        Engine engine = (Engine) ac.getBean("superEngine"); // ByName
        // Engine engine = ac.getBean(Engine.class ); // ByType 같은 타입이 3개(Engine)라 오류
        Door door = (Door) ac.getBean("door"); // ByName
        
//        변수를 직접 set하는 대신 config2.xml 파일에서 property를 설정해줌으로써 코드의 수정없이 설정 가능
//        car.setColor("red");
//        car.setOil(100);
//        car.setEngine(engine);
//        car.setDoor(new Door[] { ac.getBean("door", Door.class), (Door) ac.getBean("door")});

        System.out.println("car = " + car);
        System.out.println("engine = " + engine);
    }
}
