package com.ezen.allit.domain;

public enum Role {
	TEMP, SELLER, ADMIN
}
