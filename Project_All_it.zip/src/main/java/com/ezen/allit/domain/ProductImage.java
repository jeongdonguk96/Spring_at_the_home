package com.ezen.allit.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
public class ProductImage {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int pino;
	private String ogName;	   // 원본 파일명 
	private String storedName; // 저장된 파일명
	private String filePath;   // 저장경로
	private Long fileSize;	   // 파일크기
	@ManyToOne
	@JoinColumn(name = "pno")
	private Product product;   // 연관관계 설정용
	@ManyToOne
	@JoinColumn(name = "id")
	private Member member;	   // 연관관계 설정용
	private Date regDate;	   // 등록일
}
