package com.ezen.allit.domain;

public enum Grade {
	BRONZE, SILVER, GOLD, VIP
}
