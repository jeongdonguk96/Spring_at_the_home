package com.ezen.allit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.allit.domain.Seller;
import com.ezen.allit.repository.SellerRepository;

@Service
public class SellerServiceImpl implements SellerService {
	@Autowired
	private SellerRepository sellerRepo;

	@Override
	public Seller findByIdAndPwd(String id, String pwd) {
		
		return sellerRepo.findByIdAndPwd(id, pwd);
	}

}
