package com.ezen.allit.service;

import org.springframework.web.multipart.MultipartFile;

import com.ezen.allit.domain.Product;

public interface ProductService {
	void saveProduct(Product product, MultipartFile file) throws Exception;
}
