package com.ezen.allit.service;

import java.io.File;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.allit.domain.Product;
import com.ezen.allit.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productRepo;
	
	/*
	 *  상품등록
	 */
	public void saveProduct(Product product, MultipartFile imageFile) throws Exception {
		String ogName = imageFile.getOriginalFilename(); 										  // 원본 파일명
		String projectPath = System.getProperty("user.dir") + "/src/main/resources/static/files"; // 파일 저장경로
		
		/*
		 * UUID를 이용해 중복되지 않는 파일명 생성
		 */
		UUID uuid = UUID.randomUUID();
		String imgName = uuid + "_" + ogName; // 저장될 파일명
		
		File saveFile = new File(projectPath, imgName); // 저장경로와 파일명을 토대로 새 파일 생성 
		imageFile.transferTo(saveFile);					// 생성 완료
		
		product.setImageName(imgName);				// DB에 저장될 파일명 (DB 저장을 위해 설정(없으면 DB에 저장 안됨))
		product.setImagePath("/files/" + imgName);	// DB에 저장될 파일경로 (DB 저장을 위해 설정(없으면 DB에 저장 안됨))
		
		productRepo.save(product);
	}

}
