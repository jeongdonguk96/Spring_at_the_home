package com.ezen.allit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectAllitApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectAllitApplication.class, args);
	}

}
