package com.ezen.allit.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.allit.domain.Product;
import com.ezen.allit.domain.Seller;
import com.ezen.allit.service.ProductService;
import com.ezen.allit.service.SellerService;

@Controller
public class SellerController {
	@Autowired
	private SellerService sellerService;
	@Autowired
	private ProductService productService;
	
	// 홈 화면 이동
	@GetMapping({"", "/"})
	public String index() {
		
		return "index";
	}	
	
	// 판매자 로그인 화면 이동
	@GetMapping("/seller/login")
	public String loginView() {
		
		return "seller/login";
	}
	
	/*
	 * 판매자 로그인
	 */
	@PostMapping("/seller/login")
	public String login(String id, String pwd, HttpSession session) {
		Seller seller = sellerService.findByIdAndPwd(id, pwd);
		if(seller != null) {
			session.setAttribute("seller", seller);
			
			return "seller/main";
		} else {
			
			return "seller/login";
		}
	}
	
	// 로그아웃
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "index";
	}
	
	// 판매자 상품등록 화면 이동
	@GetMapping("/seller/insert")
	public String insertView() {
		
		return "seller/insert";
	}
	
	/*
	 * 상품등록
	 */
	@PostMapping("/seller/insert")
	public String insertProduct(Product product, MultipartFile imageFile) throws Exception {
		product.setMdPickyn("n");
		productService.saveProduct(product, imageFile);
		
		return "seller/main";
	}
	
	
}
