package com.ezen.allit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCoupangApplicationTests {

	@Test
	void contextLoads() {
	}

}
