package com.cos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cos.domain.Member;

public interface MemberRepository extends JpaRepository<Member, Integer> {
	
	public Member findByUsername(String username);
}
