package com.cos.domain;

import java.sql.Timestamp;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mno;
	private String username;
	private String password;
	private String email;
	private String role;
	private String provider; // sns 로그인 사이트 - ex)google
	private String providerId; // sns 로그인 사이트 아이디 - 임의의 난수
	@CreationTimestamp
	private Timestamp regDate;
	
	@Builder
	public Member(String username, String password, String email, String role, String provider,
			String providerId, Timestamp regDate) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
		this.role = role;
		this.provider = provider;
		this.providerId = providerId;
		this.regDate = regDate;
	}	
}
