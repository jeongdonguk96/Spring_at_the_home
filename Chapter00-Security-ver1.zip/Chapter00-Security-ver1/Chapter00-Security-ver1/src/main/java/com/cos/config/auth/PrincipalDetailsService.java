package com.cos.config.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cos.domain.Member;
import com.cos.repository.MemberRepository;

/*
 * 시큐리티가 로그인을 처리할 때 (즉, http.loginProcessingUrl이 실행될 때)
 * UserDetailsService 타입으로 IoC 되어 있는 loadUserByUsername 매서드가 실행됨
 * 여기는 username만 처리하는 곳
 */
@Service
public class PrincipalDetailsService implements UserDetailsService {
	@Autowired
	private MemberRepository memberRepo;
	
	/*
	 * UserDetails 타입으로 시큐리티 세션 저장소에 유저정보가 들어감
	 * 그리고 해당 매서드가 종료될 때 @AuthenticationPrincipal 어노테이션이 생성
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Member member = memberRepo.findByUsername(username);
		if(member != null) {
			return new PrincipalDetails(member);
		} else {
			return null;
		}
	}

}
