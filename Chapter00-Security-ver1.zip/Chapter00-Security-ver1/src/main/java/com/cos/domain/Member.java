package com.cos.domain;

import java.sql.Timestamp;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

import lombok.*;

@Getter
@Setter
@ToString
@Entity
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mno;
	private String username;
	private String password;
	private String email;
	private String role;
	private String provider; // sns 로그인 사이트
	private String providerId; // sns 로그인 사이트 아이디
	@CreationTimestamp
	private Timestamp regDate;
}
