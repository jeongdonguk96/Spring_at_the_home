package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserDto {
	private String id;
	private String pwd;
	private String name;
	private String email;
	private String phone;
	private Date regDate;
	private String role;
	private String useryn;
}
