package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OpenBoardReplyDto {
	private int bseq;
	private int brseq;
	private int parent_brseq;
	private String depth;
	private String writer;
	private String content;
	private int hit;
	private Date regDate;
	private Date modDate;
	private String obryn;
}
