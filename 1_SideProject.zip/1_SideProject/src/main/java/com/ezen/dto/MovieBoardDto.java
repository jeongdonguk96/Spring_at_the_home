package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieBoardDto {
	private int mseq;
	private int mbseq;
	private String title;
	private String writer;
	private String content;
	private int readCount;
	private int hit;
	private String uploadFile;
	private Date regDate;
	private Date modDate;
	private String mbyn;
}
