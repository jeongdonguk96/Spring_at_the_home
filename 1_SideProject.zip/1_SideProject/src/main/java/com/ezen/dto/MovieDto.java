package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieDto {
	private int mseq;
	private String title;
	private String genre;
	private String nation;
	private String director;
	private String actor;
	private String story;
	private Date openingDate;
	private int audience;
	private String photo;
	private int hit;
	private String myn;
}
