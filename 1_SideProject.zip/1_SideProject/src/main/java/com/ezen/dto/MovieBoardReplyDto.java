package com.ezen.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieBoardReplyDto {
	private int mbseq;
	private int mbrseq;
	private int parent_mbrseq;
	private String depth;
	private String writer;
	private String content;
	private int hit;
	private Date regDate;
	private Date modDate;
	private String mbryn;
}
