package com.ezen.view;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import com.ezen.dto.UserDto;
import com.ezen.user.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	
	/*
	 * 로그인
	 */
	@PostMapping("/login")
	public String login(UserDto user, Model model, HttpSession session) {
		UserDto userDto = userService.getUser(user);
		
		if(userDto == null) {

		} else {
			session.setAttribute("user", userDto);			
		}
		return "index";
	}
	
	/*
	 * 로그아웃
	 */
	
	
	/*
	 * 회원가입
	 */
	
	
	/*
	 * 아이디 수정
	 */
	
	
	/*
	 * 비밀번호 수정
	 */
	
	
	/*
	 * 회원탈퇴
	 */
}
