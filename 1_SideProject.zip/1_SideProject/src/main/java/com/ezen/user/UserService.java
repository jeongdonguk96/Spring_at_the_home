package com.ezen.user;

import com.ezen.dto.UserDto;

public interface UserService {
	UserDto getUser(UserDto user);
	
	void insertUser();
	
	void updateId(UserDto user);
	
	void updatePwd(UserDto user);
	
	void deleteUser(UserDto user);
}
