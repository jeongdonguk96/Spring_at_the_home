package com.ezen.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezen.dao.UserDao;
import com.ezen.dto.UserDto;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	
	// 로그인
	@Override
	public UserDto getUser(UserDto user) {
		return userDao.getUser(user);
	}

	// 회원가입
	@Override
	public void insertUser() {
		userDao.insertUser();
	}

	// 아이디 수정
	@Override
	public void updateId(UserDto user) {
		userDao.updateId(user);
	}

	// 비밀번호 수정
	@Override
	public void updatePwd(UserDto user) {
		userDao.updatePwd(user);
	}

	// 회원탈퇴
	@Override
	public void deleteUser(UserDto user) {
		userDao.deleteUser(user);
	}

}
