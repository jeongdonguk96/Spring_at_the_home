package com.ezen.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ezen.dto.UserDto;

@Repository
public class UserDao {
	@Autowired
	private SqlSessionTemplate myBatis;
	
	// 로그인
	public UserDto getUser(UserDto user) {
		
		return myBatis.selectOne("userMapper.getUser", user);
	}
	
	// 회원가입
	public void insertUser() {
		
		myBatis.insert("userMapper.insertUser");
	}
	
	// 아이디 수정
	public void updateId(UserDto user) {
		
		myBatis.update("userMapper.updateId", user);
	}
	
	// 비밀번호 수정
	public void updatePwd(UserDto user) {
		
		myBatis.update("userMapper.updatePwd", user);
	}
	
	// 회원탈퇴
	public void deleteUser(UserDto user) {
		
		myBatis.delete("userMapper.deleteUser", user);
	}
}
