package com.ezen.board.service;

import org.springframework.stereotype.Service;

import com.ezen.board.dto.Board;
import com.ezen.board.dto.Comment;
import com.ezen.board.entity.BoardEntity;
import com.ezen.board.entity.CommentEntity;
import com.ezen.board.persistence.BoardRepository;
import com.ezen.board.persistence.CommentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CommentService {
	private final CommentRepository commentRepo;
	private final BoardRepository boardRepo;
	
	public int save(Comment comment) {
		BoardEntity boardEntity = boardRepo.findById(comment.getBno()).get();
		CommentEntity commentEntity = CommentEntity.toSaveEntity(comment, boardEntity);
		
		return commentRepo.save(commentEntity).getCno();
	}
}
