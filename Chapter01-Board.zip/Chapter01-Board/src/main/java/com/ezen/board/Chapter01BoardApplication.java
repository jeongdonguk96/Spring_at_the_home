package com.ezen.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter01BoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter01BoardApplication.class, args);
	}

}
