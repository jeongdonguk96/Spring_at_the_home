package com.ezen.board.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.ezen.board.dto.Comment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class CommentEntity extends BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int cno;
	private String commentWriter;
	private String commentContents;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bno")
	private BoardEntity boardEntity;
	
	public static CommentEntity toSaveEntity(Comment comment, BoardEntity boardEntity) {
		CommentEntity commentEntity = new CommentEntity();
		commentEntity.setCommentWriter(comment.getCommentWriter());
		commentEntity.setCommentContents(comment.getCommentContents());
		commentEntity.setBoardEntity(boardEntity);
		
		return commentEntity;
	}
}
