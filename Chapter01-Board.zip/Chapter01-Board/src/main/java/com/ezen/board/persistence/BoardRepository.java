package com.ezen.board.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ezen.board.entity.BoardEntity;

public interface BoardRepository extends JpaRepository<BoardEntity, Integer> {
	@Modifying
	@Query(value = "UPDATE BoardEntity b SET b.boardHits = b.boardHits+1 WHERE b.bno = :bno")
	void updateHits(@Param("bno") int bno);
}
