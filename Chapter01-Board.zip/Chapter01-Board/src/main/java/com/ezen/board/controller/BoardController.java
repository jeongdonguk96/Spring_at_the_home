package com.ezen.board.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.board.dto.Board;
import com.ezen.board.service.BoardService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/board")
@RequiredArgsConstructor
public class BoardController {
	private final BoardService boardService;

	@GetMapping("/save")
	public String saveView() {
		return "save";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute Board board) throws Exception {
		boardService.save(board);
		
		return "index";
	}
	
	@GetMapping("/")
	public String findAll(Model model) {
		List<Board> boardList = boardService.findAll();
		model.addAttribute("boardList", boardList);
		
		return "list";
	}
	
	@GetMapping("/{bno}")
	public String findById(@PathVariable int bno, Model model,	
							@PageableDefault(page = 1) Pageable pageable) {
		boardService.updateHits(bno);
		Board board = boardService.findById(bno);
		model.addAttribute("board", board);
		model.addAttribute("page", pageable.getPageNumber());
		
		return "detail";
	}
	
	@GetMapping("/update/{bno}")
	public String updateView(@PathVariable int bno, Model model) {
		Board board = boardService.findById(bno);
		model.addAttribute("boardUpdate", board);
		
		return "update";
	}
	
	@PostMapping("/update")
	public String update(@ModelAttribute Board board, Model model) {
		Board theBoard = boardService.update(board);
		model.addAttribute("board", theBoard);
		
		return "detail";
	}
	
	@GetMapping("/delete/{bno}")
	public String delete(@PathVariable int bno) {
		boardService.delete(bno);
		
		return "redirect:/board/";
	}
	
	@GetMapping("/paging")
	public String paging(@PageableDefault(page = 1) Pageable pageable, Model model) {	
		Page<Board> boardList = boardService.paging(pageable);
		int blockLimit = 10;
		int startPage = (((int)(Math.ceil((double)pageable.getPageNumber() / blockLimit))) - 1) * blockLimit + 1; // 1 11 21 31 ~~
        int endPage = ((startPage + blockLimit - 1) < boardList.getTotalPages()) ? startPage + blockLimit - 1 : boardList.getTotalPages();
        
        model.addAttribute("boardList", boardList);
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        
        return "paging";
	}
	
}










