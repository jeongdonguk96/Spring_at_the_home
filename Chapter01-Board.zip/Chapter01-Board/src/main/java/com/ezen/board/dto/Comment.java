package com.ezen.board.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Comment {
	private int cno;
	private String commentWriter;
	private String commentContents;
	private int bno;
	private Date commentCreatedTime;
}
