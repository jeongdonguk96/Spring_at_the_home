package com.ezen.board.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ezen.board.entity.BoardEntity;
import com.ezen.board.entity.BoardFileEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
public class Board {
	private int bno;
	private String boardWriter;
	private String boardPass;
	private String boardTitle;
	private String boardContents;
	private int boardHits;
	private Date boardCreatedTime;
	private Date boardUpdatedTime;
	private List<MultipartFile> boardFile;
	private List<String> originalFileName;
	private List<String> storedFileName;
	private int fileAttached;
	
	// 페이징을 위한 생성자
	public Board(int bno, String boardWriter, String boardTitle, int boardHits, Date boardCreatedTime) {
		super();
		this.bno = bno;
		this.boardWriter = boardWriter;
		this.boardTitle = boardTitle;
		this.boardHits = boardHits;
		this.boardCreatedTime = boardCreatedTime;
	}
	
	public static Board toBoard(BoardEntity boardEntity) {
		Board board = new Board();
		board.setBno(boardEntity.getBno());
		board.setBoardWriter(boardEntity.getBoardWriter());
		board.setBoardPass(boardEntity.getBoardPass());
		board.setBoardTitle(boardEntity.getBoardTitle());
		board.setBoardContents(boardEntity.getBoardContents());
		board.setBoardHits(boardEntity.getBoardHits());
		board.setBoardCreatedTime(boardEntity.getCreatedTime());
		board.setBoardUpdatedTime(boardEntity.getUpdatedTime());
		if(boardEntity.getFileAttached() == 0) {
			board.setFileAttached(boardEntity.getFileAttached());
		} else {
			List<String> originalFileNameList = new ArrayList<>();
			List<String> storeFileNameList = new ArrayList<>();
			board.setFileAttached(boardEntity.getFileAttached());
			
			for(BoardFileEntity boardFileEntity : boardEntity.getBoardFileEntityList()) {				
				originalFileNameList.add(boardFileEntity.getOriginalFileName());
				storeFileNameList.add(boardFileEntity.getStoredFileName());
			}
			board.setOriginalFileName(originalFileNameList);
			board.setStoredFileName(storeFileNameList);
		}
		
		return board;
	}
}
