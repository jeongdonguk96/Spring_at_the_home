package com.ezen.board.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
public class BoardFileEntity extends BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int bfno;
	private String originalFileName;
	private String storedFileName;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bno")
	private BoardEntity boardEntity;
	
	public static BoardFileEntity toBoardFileEntity(BoardEntity boardEntity, String originalFileName, String storedFileName) {
		BoardFileEntity boardFileEntity = new BoardFileEntity();
		boardFileEntity.setOriginalFileName(originalFileName);
		boardFileEntity.setStoredFileName(storedFileName);
		boardFileEntity.setBoardEntity(boardEntity);
		
		return boardFileEntity;
	}
}
