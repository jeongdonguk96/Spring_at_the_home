package com.ezen.board.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ezen.board.dto.Board;
import com.ezen.board.entity.BoardEntity;
import com.ezen.board.entity.BoardFileEntity;
import com.ezen.board.persistence.BoardFileRepository;
import com.ezen.board.persistence.BoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardService {
	private final BoardRepository boardRepo;
	private final BoardFileRepository boardFileRepo;
	
	// 글 등록, 파일첨부 여부에 따라 로직 분리
	public void save(Board board) throws Exception {
		if(board.getBoardFile().isEmpty()) {
			BoardEntity boardEntity = BoardEntity.toSaveEntity(board);
			boardRepo.save(boardEntity);			
		} else {
			BoardEntity boardEntity = BoardEntity.toSaveFileEntity(board);
			int savedBno = boardRepo.save(boardEntity).getBno();
			BoardEntity theBoardEntity = boardRepo.findById(savedBno).get();

			for(MultipartFile boardFile : board.getBoardFile()) {	
			String originalFileName = boardFile.getOriginalFilename();
			String storedFileName = System.currentTimeMillis() + "_" + originalFileName;
			String savePath = "c:/boardfile/" + storedFileName;
			boardFile.transferTo(new File(savePath));
			
			BoardFileEntity boardFileEntity = BoardFileEntity.toBoardFileEntity(theBoardEntity, originalFileName, storedFileName);
			boardFileRepo.save(boardFileEntity);
			}
		}
	}
	
	// 글 목록 조회
	@Transactional
	public List<Board> findAll() {
		List<BoardEntity> boardEntityList = boardRepo.findAll();
		List<Board> boardList = new ArrayList<Board>();
		
		for(BoardEntity boardEntity : boardEntityList) {
			boardList.add(Board.toBoard(boardEntity));
		}
		
		return boardList;
	}
	
	// 글 조회수 증가
	@Transactional
	public void updateHits(int bno) {
		boardRepo.updateHits(bno);
	}
	
	// 글 조회
	@Transactional
	public Board findById(int bno) {
		BoardEntity boardEntity = boardRepo.findById(bno).get();
		Board board = Board.toBoard(boardEntity);
		
		return board;
	}
	
	// 글 수정
	public Board update(Board board) {
		BoardEntity boardEntity = BoardEntity.toUpdateEntity(board);
		boardRepo.save(boardEntity);		
		
		return findById(board.getBno());
	}
	
	// 글 삭제
	public void delete(int bno) {
		boardRepo.deleteById(bno);
	}
	
	// 페이징
	public Page<Board> paging(Pageable pageable) {
		int page = pageable.getPageNumber() - 1;
		int pageSize = 3;
		Page<BoardEntity> boardEntityList =
				boardRepo.findAll(PageRequest.of(page, pageSize, Sort.by(Sort.Direction.DESC, "bno")));
		
		System.out.println("boardEntityList.getContent() = " + boardEntityList.getContent()); // 요청 페이지에 해당하는 글
        System.out.println("boardEntityList.getTotalElements() = " + boardEntityList.getTotalElements()); // 전체 글갯수
        System.out.println("boardEntityList.getNumber() = " + boardEntityList.getNumber()); // DB로 요청한 페이지 번호
        System.out.println("boardEntityList.getTotalPages() = " + boardEntityList.getTotalPages()); // 전체 페이지 갯수
        System.out.println("boardEntityList.getSize() = " + boardEntityList.getSize()); // 한 페이지에 보여지는 글 갯수
        System.out.println("boardEntityList.hasPrevious() = " + boardEntityList.hasPrevious()); // 이전 페이지 존재 여부
        System.out.println("boardEntityList.isFirst() = " + boardEntityList.isFirst()); // 첫 페이지 여부
        System.out.println("boardEntityList.isLast() = " + boardEntityList.isLast()); // 마지막 페이지 여부
        Page<Board> boardList = boardEntityList.map(boardEntity -> new Board(boardEntity.getBno(), boardEntity.getBoardWriter(), boardEntity.getBoardTitle(), boardEntity.getBoardHits(), boardEntity.getCreatedTime()));
        // map(): Page 객체가 가진 매서드
        // forEach문처럼 boardEntiryList의 리스트만큼 하나씩 꺼내 boardDto에 담는 것
        
        return boardList;
	}
	
}







