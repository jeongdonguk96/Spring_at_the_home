package com.ezen.board.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.board.dto.Comment;
import com.ezen.board.service.CommentService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/comment")
@RequiredArgsConstructor
public class CommentController {
	private final CommentService commentService;
	
	@PostMapping("/save")
	public String save(@ModelAttribute Comment comment) {
		Long saveResult = (long) commentService.save(comment);
		if(saveResult == null) {
			List<Comment> commentList = commentService.findAll(comment.getBno());
			
			return "성공";
		} else {
			return "실패";
		}
	}
}
