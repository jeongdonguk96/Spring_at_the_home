package com.ezen.board.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.ezen.board.dto.Board;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
public class BoardEntity extends BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int bno;
	private String boardWriter;
	private String boardPass;
	private String boardTitle;
	private String boardContents;
	private int boardHits;
	private int fileAttached;
	@OneToMany(mappedBy = "boardEntity", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private List<BoardFileEntity> boardFileEntityList = new ArrayList<>();
	@OneToMany(mappedBy = "boardEntity", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	private List<CommentEntity> commentEntityList = new ArrayList<>();
	
	public static BoardEntity toSaveEntity(Board board) {
		BoardEntity boardEntity = new BoardEntity();
		boardEntity.setBoardWriter(board.getBoardWriter());
		boardEntity.setBoardPass(board.getBoardPass());
		boardEntity.setBoardTitle(board.getBoardTitle());
		boardEntity.setBoardContents(board.getBoardContents());
		boardEntity.setBoardHits(0);
		boardEntity.setFileAttached(0);
		
		return boardEntity;
	}
	
	public static BoardEntity toSaveFileEntity(Board board) {
		BoardEntity boardEntity = new BoardEntity();
		boardEntity.setBoardWriter(board.getBoardWriter());
		boardEntity.setBoardPass(board.getBoardPass());
		boardEntity.setBoardTitle(board.getBoardTitle());
		boardEntity.setBoardContents(board.getBoardContents());
		boardEntity.setBoardHits(0);
		boardEntity.setFileAttached(1);
		
		return boardEntity;
	}
	
	public static BoardEntity toUpdateEntity(Board board) {
		BoardEntity boardEntity = new BoardEntity();
		boardEntity.setBno(board.getBno());
		boardEntity.setBoardWriter(board.getBoardWriter());
		boardEntity.setBoardPass(board.getBoardPass());
		boardEntity.setBoardTitle(board.getBoardTitle());
		boardEntity.setBoardContents(board.getBoardContents());
		boardEntity.setBoardHits(board.getBoardHits());
		
		return boardEntity;
	}
}
